# Responsive Animated and Colourful Portfolio
 
<figure>
  <figcaption>Website View (on desktop screen)</figcaption>
  <img src="images/website.gif" alt="Website View" width="700">
</figure>

<figure>
  <figcaption>Screenshot 1 (on desktop screen)</figcaption>
  <img src="images/Screenshot_1.png" alt="Screenshot 1" width="700">
</figure>
